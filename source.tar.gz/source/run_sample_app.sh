#!/bin/bash
source ./env.sh

java -classpath target/demo-0.0.1-SNAPSHOT.jar demo.RedisCache